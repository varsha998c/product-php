<?php
include 'db_connection.php';
include 'header.php';

$conn = OpenCon();

$sql = "SELECT * FROM product ";


$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $table_data = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $table_data[] = $row;
    }
}

if (isset($_POST['addToCart'])) {
    
    $product = $_POST['product']; 
    $price = $_POST['price']; 
    $pId = $_POST['id'];
    $count = $_POST['count']; 

    $query = "INSERT INTO cart (id,name,price,count) VALUES ('$pId','$product','$price','$count')";
    $results = mysqli_query($conn, $query);
    if ($results > 0) {
        echo "Product added to cart successfully";
    } else {
        echo "Error adding product to cart: " . mysqli_error($conn);
    }
}
CloseCon($conn);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .container {
        width: 90%;
        background: #f0f0f0;
        margin: 0 auto;
        padding: 20px;
    }
    .top {
        background: aliceblue;
        padding: 15px;
        margin-bottom: 30px;
    }
    .right {
        width: 40%;
    margin: 0 0 0 auto;
    }
    .cart {
        width: 40px;
    background: #00d0ff;
    height: 40px;
    border-radius: 50%;
    position: relative;
    cursor: pointer;
    }
    span {
        position: absolute;
    top: 10px;
    left: 6px;
    }
    .button {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 90px;
        border: 1px solid #000;
    }
    .item{
        width: 100%;
        display: flex;
    flex-wrap: wrap;
    gap: 30px;
    justify-content: space-between;
    }
    .carts {
        width: 30%;
    padding: 20px;
    border-radius: 10px;
    background: #fff;
    }
</style>

<body>
    <div>
        <a href="Details.php">Back</a>
    </div>
    <div class="container">
        <div class="top">
            <div class="right">
                <div class="cart">   
                    <a href="cart.php" id="myHref">
                        <span id="count">total</span>
                    </a>
       
                </div>
            </div>
        </div>
        <div class="item">
            
            <?php

            if (isset($table_data) && count($table_data) > 0) {
                foreach ($table_data as $data) {
                    $imageFileName = $data['image'];
                    $imagesFolderPath = 'images/';
                    $imageSrc = $imagesFolderPath . $imageFileName;

                    echo "<div class='carts'>"
                    ?>
                        <form method="POST" action="">
                            <input type="" style="border:none;" name="id" value="<?= $data['id'] ?>"/>
                            <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                                <label for="product name">Product name:</label>
                               <input style="padding:5px" value="<?= $data['product'] ?>" name="product" />

                               <input type="hidden" name="count" id="count<?= $data['id'] ?>" value="0"/>

                            </div>
                            <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                                <label for="category">Category:</label>
                               <input style="padding:5px" value="<?= $data['category'] ?>" />
                            </div>
                            <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                                <label for="quantity">Quantity:</label>
                               <input style="padding:5px" value="<?= $data['quantity'] ?>" />
                            </div>
                            <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                                <label for="price">Price:</label>
                               <input style="padding:5px" value="<?= $data['price'] ?>" name="price"/>
                            </div>
                            <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                                <label for="image">Image:</label>
                       
                                <img src="<?php echo $imageSrc; ?>" style="width:100px;" alt="product <?php echo $data['id']; ?>" />
                            </div>
                            <div class="button">
                                <div class="add" style="background:#fff;padding:5px; cursor:pointer" onclick="incrementCount('<?= $data['id'] ?>')">+</div>
                               
                                <div id="counts<?= $data['id'] ?>" name="count">0</div>
                                <div class="minus" style="background:#fff;padding:5px; cursor: pointer;" onclick="decrementCount('<?= $data['id'] ?>')">-</div>
                            </div>
                            <button type="submit" name="addToCart" value="<?= $data['id'] ?>" style="cursor:pointer;">Add</button>
                        </form>
                    <?php
                        echo "</div>";
                }
            }

            ?>
            
        </div>
    </div>
    <script>
        var countNumber = {};
        function updateCartCount(productId){
            var countItem =document.getElementById('counts' + productId);
            countItem.textContent = countNumber[productId];
            var totalCartItem = 0 ;
            for(var id in countNumber){
                totalCartItem +=countNumber[id];
            }
            document.getElementById('count').textContent =totalCartItem;
            document.getElementById('count' + productId).value =  countItem.textContent;

           
        }

                function incrementCount(productId) {
                    countNumber[productId] = (countNumber[productId] || 0) + 1;
                    updateCartCount(productId);

                }
                function decrementCount(productId){
                    if(countNumber[productId]&& countNumber[productId]>0){
                        countNumber[productId] -= 1;
                        updateCartCount(productId)
                    }
                }


    // document.addEventListener("DOMContentLoaded", function() {
    //     const addButtons = document.querySelectorAll(".add");
    //     const minusButtons = document.querySelectorAll(".minus");
    //     const countElements = document.querySelectorAll(".count");
    //     const countItems = document.querySelectorAll(".counts");


    //     addButtons.forEach((addButton, index) => {
    //         console.log("varsha");
    //         addButton.addEventListener("click", function() {
    //             const currentCount = parseInt(countElements[index].textContent);
    //             const countItemCount =parseInt(countItems[index].textContent);
    //             countItems[index].textContent = countItemCount +1;
    //             countElements[index].textContent = currentCount + 1;
    //         });
    //     });

    //     minusButtons.forEach((minusButton, index) => {
    //         minusButton.addEventListener("click", function() {
    //             const currentCount = parseInt(countElements[index].textContent);
    //             const countItemCount =parseInt(countItems[index].textContent);
                
    //             if (currentCount > 0) {
    //                 countElements[index].textContent = currentCount - 1;
    //                 countItems[index].textContent = countItemCount - 1;
    //             }
    //         });
    //     });
    // });

</script>
</body>
</html>