<!-- 
// include 'db_connection.php';
// $conn = OpenCon();
// echo "Connected Successfully";

// $errMsg = '';
// $id = "";
// $product = $category = $quantity = $price = "";
// $imagePath = '';

// if ($_SERVER['REQUEST_METHOD'] == "POST") {

//     $product = $_POST["product"];
//     $category = $_POST["category"];
//     $quantity = $_POST["quantity"];
//     $price = $_POST["price"];
//     $imagePath =  $_FILES["img"]["name"];
    
//     if (empty($product)) {
//         $errMsg = "Error! You didn't enter the Name.";
//     } else {
//         if (!preg_match("/^[a-zA-Z ]*$/", $product)) {
//             $errMsg = "Only alphabets and whitespace are allowed.";
//         }


//     }
//     if (empty($category)) {
//         $errMsg = "Error! You didn't enter the email.";
//     } else {
//         if (!preg_match("/^[a-zA-Z ]*$/", $category)) {
//             $errMsg = "Only alphabets and whitespace are allowed.";
//         }
       
//     }
//     if (mysqli_query($conn, $sql)) {
//         $product = mysqli_real_escape_string($conn, $product);
//         $category = mysqli_real_escape_string($conn, $category);
//         $price = mysqli_real_escape_string($conn, $price);
//         $quantity = mysqli_real_escape_string($conn, $quantity);
//         $imagePath = mysqli_real_escape_string($conn, $imagePath);
//     }
   
//     $destinationFolder = 'images/';
//     $destinationFile = $destinationFolder . basename($_FILES["img"]["name"]);
//     if (move_uploaded_file($_FILES["img"]["tmp_name"], $destinationFile)) {
//         echo "Image uploaded successfully.";
//     } else {
//         echo "Failed to move the image.";
//     }

    

//     $sql = "INSERT INTO product (id,product,category,quantity,price,image) VALUES ('$id','$product','$category','$quantity','$price','$imagePath')";

//     if (mysqli_query($conn, $sql)) {
//         echo "Data inserted successfully!";
//         header("Location: productTable.php");
//     } else {
//         echo "Error: " . $sql . "<br>" . $conn->error;
//     }

// }


// $conn->close(); -->

<?php
$nameErr = $catErr = $priceErr = $imgErr = $quantityErr= "";
$name = $category = $price = $image = $quantity = "";
include 'db_connection.php';
include 'header.php';
$conn = OpenCon();
if($conn){
    echo "db connected";
}else{
    echo "db not connected";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["product"])) {
        $nameErr = "product name is required";
    } else {
        $product = $_POST["product"];
    }
    if (empty($_POST["category"])) {
        $catErr = "category is required";
    } else {
        $category = $_POST["category"];
    }
    if (empty($_POST["price"])) {
        $priceErr = "price is required";
    } else {
        $price = $_POST["price"];
    }
    if (empty($_POST["quantity"])) {
        $quantityErr = "quantity is required";
    } else {
        $quantity = $_POST["quantity"];
    }
    if (empty($_FILES["img"]["name"])) {
        $imgErr = "img is required";
    } else {
        $image = $_FILES["img"]["name"];
    }
    if (empty($nameErr) && empty($catErr) && empty($priceErr) && empty($quantityErr) && empty($imgErr)) {
        $name = mysqli_real_escape_string($conn, $name);
        $category = mysqli_real_escape_string($conn, $category);
        $price = mysqli_real_escape_string($conn, $price);
        $image = mysqli_real_escape_string($conn, $image);
        $quantity = mysqli_real_escape_string($conn, $quantity);
        $sql = "INSERT INTO product (product, category, quantity, price, image) VALUES ('$product', '$category', '$quantity', '$price', '$image')";
        if (mysqli_query($conn, $sql)) {
            echo "connnected";
            $destinationFolder = 'images/';
            $destinationFile = $destinationFolder . basename($_FILES["img"]["name"]);
            if (move_uploaded_file($_FILES["img"]["tmp_name"], $destinationFile)) {
                echo "Image uploaded successfully.";
            } else {
                echo "Failed to move the image.";
            }
            echo "Data inserted successfully";
            header("Location: productTable.php");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}
CloseCon($conn);
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    div.container {
        display: flex;

        justify-content: space-between;
        flex-direction: column;
    }

    label {
        margin-bottom: 10px;
    }

    input {
        padding: 10px;
        margin-bottom: 20px;
    }
</style>

<body>
    <div>
        <a href="Details.php">Back</a>
    </div>
    <div style="width: 500px; margin: 0 auto; " id="form">
        <h1>Product Form</h1>
        <form action="" method="post" style="background-color: aliceblue;
    padding: 20px;" enctype="multipart/form-data">
            <div class="container">
                <label for="id">Id </label>
                <input type="number" name="id" placeholder="Id" />

            </div>

            <div class="container">
                <label for="product">Product </label>
                <input type="text" name="product" placeholder="Product" />
            </div>

            <div class="container">
                <label for="category">Category </label>
                <input type="text" name="category" placeholder="Category" />
            </div>

            <div class="container">
                <label for="quantity">Quantity </label>
                <input type="number" name="quantity" placeholder="Quantity" />
            </div>

            <div class="container">
                <label for="price">Price </label>
                <input type="text" name="price" placeholder="Price" />
            </div>

            <div class="container">
                <label for="file">Image </label>
                <input type="file" id="img" name="img" required>
            </div>
            <br>
            <div style="margin: 0 auto; width: 100%;">
                <button type="submit"
                    style="width: 100%;background-image: linear-gradient(315deg, #20bf55 0%, #01baef 74%);padding: 10px;border: none;border-radius: 10px;color:#fff; cursor:pointer;">Submit</button>
            </div>

        </form>
    </div>
</body>

</html>