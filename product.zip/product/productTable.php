<?php 
include 'db_connection.php';
include 'header.php';
$conn = OpenCon();

$sql = "SELECT * FROM product ";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result) > 0){
    $table_data = array();
    while ($row = mysqli_fetch_assoc($result)){
        $table_data[] = $row;
    }
}
CloseCon($conn);
?>


<!DOCTYPE html>
<html lang="en">
    <style>
        table {
                border-collapse: collapse;
                width: 100%;
            }

            th, td {
                text-align: left;
                padding: 8px;
                border: 1px solid black;
                border-collapse: collapse;
            }

            tr:nth-child(even) {
                background-color: #D6EEEE;
        }
    </style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>
        <h1>Product Table</h1>
        
        <a href="searchForm.php">Search</a>
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Image</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if(isset($table_data) && count($table_data)>0){
                    foreach ($table_data as $data) {
                        echo "<tr>";
                        echo "<td>" . $data['id'] ."</td>";
                        echo "<td>" . $data['product'] ."</td>";
                        echo "<td>" . $data['category'] ."</td>";
                        echo "<td>" . $data['quantity'] ."</td>";
                        echo "<td>" . $data['price'] ."</td>";
                        echo "<td>" . $data['image'] ."</td>";
                        echo "</tr>";
                    }
                }
                else {
                    
                    echo "";
                }
                ?>
               
            </tbody>
        </table>
    </div>
</body>
</html>