<?php
include 'db_connection.php';
include 'header.php';

$conn = OpenCon();
$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM cart WHERE userId = '$user_id'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result) > 0){
    $table_data = array();
    while ($row = mysqli_fetch_assoc($result)){
        $table_data[] = $row;
    }
}
CloseCon($conn);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    
</head>
<style>
    td {
        text-transform: capitalize;
    }
</style>
<body>
    <div id="cartList" style="width: 90%;
    background: #f0f0f0;
    margin: 0 auto;
    padding: 20px;">
        <div>
            <div>
                <div>
                    <h5>Cart</h5>
                </div>
                <div class="modal-body">
                    <table class="show-cart table">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>name</th>
                                <th>price</th>
                                <th>count</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                if(isset($table_data) && count($table_data)>0){
                    foreach ($table_data as $data) {
                        echo "<tr>";
                        echo "<td>" . $data['id'] ."</td>";
                        echo "<td>" . $data['name'] ."</td>";
                        echo "<td>" . $data['price'] ."</td>";
                        echo "<td>" . $data['count'] ."</td>";
                        echo "</tr>";
                    }
                }
                else {
                    
                    echo "";
                }
                ?>
                        </tbody>
                        
                    </table>
                    
                </div>
            </div>
        </div>
    </div> 

</body>
</html>