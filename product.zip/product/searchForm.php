<?php
include 'db_connection.php';
include 'header.php';
OpenCon();
echo "Connected Successfully";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .item { 
        display: flex;
        justify-content: space-between;
        margin-bottom: 30px;
        align-items: center;
    }
    input {
        width: 240px;
        border: none;
        padding: 10px;
    }
    .main {
        background:#FFEBE9;
        width:400px;
        padding:30px;
        border-radius:10px;
        margin:0 auto; 
        cursor:pointer; 
        height:200px;
    }
    
</style>
<body>
    <h1 style="text-align:center;">Search Form</h1>
    <a href="productForm.php">Back</a>
    <div class="main" >
        
        <form action="searchDetails.php" method="POST" style="display:flex;flex-direction: column; justify-content: space-between;height: 80%;">
            <div>
                <div class="item">
                    <label for="id">Id</label>
                    <input type="number" name="id" placeholder="id"/>
                </div>
                <div class="item">
                    <label for="product">product</label>
                    <input type="text" name="product" placeholder="product"/>
                </div>
                <div class="item">
                    <label for="category">category</label>
                    <input type="text" name="category" placeholder="category"/>
                </div>
            </div>
            <div style="width:100%;">
                <button type="submit" style="width:100%; background-color: #6CD6DC;padding:10px; border:none;cursor:pointer">Search</button>
            </div>
        </form>
    </div>
</body>
</html>