
<?php 
ob_start();
session_start(); 

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $user_id = $_SESSION['user_id'];
} 
else {
    echo "You are not logged in.";
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php"); 
    exit;
}
// session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    li {
        text-transform: capitalize;
    }
    li:last-child {
        cursor: pointer;
        border: 1px solid #000;
        border-radius: 30px;
        padding: 5px;
    }
</style>
<body>
    <div style="height:40px; background:#cfcfcf; padding: 10px;">
        <div class="right" style="margin: 0 0 0 auto; width:15%;">
            <ul style="display:flex; justify-content: space-between; list-style:none; align-items:center;margin:0;">
            <?php
                
                // if (isset($_SESSION['username'])) {
                    echo '<li>' . $username . '</li>';
                    echo '<li><a href="?logout=true">Log out</a></li>'; 
                // }
                ?>
                <!-- <li>log out</li> -->
            </ul>
        </div>
    </div>
</body>
</html>