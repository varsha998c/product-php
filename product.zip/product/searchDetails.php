<?php
include 'db_connection.php';
include 'header.php';

$conn = OpenCon();
$category = $_POST['category'];
$product = $_POST['product'];


$sql = "SELECT * FROM product  WHERE category = '$category' OR product = '$product'";
// WHERE category = '$category' OR product = '$product'

$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $table_data = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $table_data[] = $row;
    }
}

$count = 0;
$product = $price  = $userId = $id= "";
$query = "INSERT INTO cart (id,userId,name,price,count) VALUES ('$id','$userId','$product','$price','$count')";
$results = mysqli_query($conn, $query);



?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .container {
        width: 90%;
        background: #f0f0f0;
        margin: 0 auto;
        padding: 20px;
    }
    .top {
        background: aliceblue;
        padding: 15px;
        margin-bottom: 30px;
    }
    .right {
        width: 40%;
    margin: 0 0 0 auto;
    }
    .cart {
        width: 40px;
    background: #00d0ff;
    height: 40px;
    border-radius: 50%;
    position: relative;
    cursor: pointer;
    }
    span {
        position: absolute;
    top: 10px;
    left: 15px;
    }
    .button {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 90px;
        border: 1px solid #000;
    }
    .item{
        width: 100%;
        display: flex;
    flex-wrap: wrap;
    gap: 30px;
    justify-content: space-between;
    }
    .carts {
        width: 30%;
    padding: 20px;
    border-radius: 10px;
    background: #fff;
    }
</style>

<body>
    <div class="container">
        <div class="top">
            <div class="right">
                <div class="cart">   
                    <a href="cart.php" id="myHref">
                        <span id="count">0</span>
                        </a>
                         
                </div>
            </div>
        </div>
        <div class="item">
            
            <?php

            if (isset($table_data) && count($table_data) > 0) {
                foreach ($table_data as $data) {
                    $imageFileName = $data['image'];
                    $imagesFolderPath = 'images/';
                    $imageSrc = $imagesFolderPath . $imageFileName;

                    echo "<div class='carts'>"

                        ?>

                            <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                                <label for="product name">Product name:</label>
                               <input style="padding:5px" value="<?= $data['product'] ?>" />
                            </div>
                            <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                                <label for="category">Category:</label>
                               <input style="padding:5px" value="<?= $data['category'] ?>" />
                            </div>
                            <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                                <label for="quantity">Quantity:</label>
                               <input style="padding:5px" value="<?= $data['quantity'] ?>" />
                            </div>
                            <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                                <label for="price">Price:</label>
                               <input style="padding:5px" value="<?= $data['price'] ?>" />
                            </div>
                            <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                                <label for="image">Image:</label>
                       
                                <img src="<?php echo $imageSrc; ?>" style="width:100px;" alt="product <?php echo $data['id']; ?>" />
                            </div>
                            <div class="button">
                                <div class="add" style="background:#fff;padding:5px; cursor:pointer" onclick="incrementCount('<?= $data['id'] ?>')">+</div>
                                
                                <div id="counts<?= $data['id'] ?>">0</div>
                                <div class="minus" style="background:#fff;padding:5px; cursor: pointer;" onclick="decrementCount('<?= $data['id'] ?>')">-</div>
                            </div>
                            <button type="submit" id="addToCart"  style="cursor:pointer;">Add</button>
                    
                        <?php
                            echo "</div>";
                }
            }

            ?>
            
        </div>
    </div>
    <script>
        var countNumber = {};
        function updateCartCount(productId){
            var countItem =document.getElementById('counts' + productId);
            countItem.textContent = countNumber[productId];
            var totalCartItem = 0 ;
            for(var id in countNumber){
                totalCartItem +=countNumber[id];
            }
            document.getElementById('count').textContent =totalCartItem;
        }

                function incrementCount(productId) {
                    countNumber[productId] = (countNumber[productId] || 0) + 1;
                    console.log('count nuber',countNumber[productId]);
                    updateCartCount(productId);

                }
                function decrementCount(productId){
                    if(countNumber[productId]&& countNumber[productId]>0){
                        countNumber[productId] -= 1;
                        updateCartCount(productId)
                    }
                }

</script>
</body>
</html>