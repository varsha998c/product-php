<?php
session_start(); 
include 'header.php';
include 'db_connection.php';
$conn = OpenCon();

if(!isset($_SESSION['username'])){
    header('Location:login.php');
}

$sql = "SELECT * FROM product";

$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result) > 0){
    $table_data = array();
    while ($row = mysqli_fetch_assoc($result)){
        $table_data[] = $row;
    }
}

CloseCon($conn);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .container {
        width: 90%;
        background: #f0f0f0;
        margin: 0 auto;
        padding: 20px;
    }
    .top {
        background: aliceblue;
        padding: 15px;
        margin-bottom: 30px;
    }
    .right {
        width: 40%;
    margin: 0 0 0 auto;
    }
    .cart {
        width: 40px;
    background: #00d0ff;
    height: 40px;
    border-radius: 50%;
    position: relative;
    cursor: pointer;
    }
    span {
        position: absolute;
    top: 10px;
    left: 15px;
    }
    .button {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 90px;
        border: 1px solid #000;
    }
    .item{
        width: 100%;
        display: flex;
    flex-wrap: wrap;
    gap: 30px;
    justify-content: space-between;
    }
    .carts {
        width: 30%;
    padding: 20px;
    border-radius: 10px;
    background: #fff;
    }
</style>

<body>
    <div style="display:flex;">
        <div style="width: 60px;
    display: flex;
    background: #00ffc4;
    justify-content: center;
    align-items: center;
    padding: 5px;
     ">
            <a href="cartPage.php" style="text-decoration:none; color: #fff;">Cart</a>
        </div>
        
        <br>
        <div style="width: 112px;
    padding: 4;
    background: antiquewhite;
    display: flex;
    justify-content: center;
    align-items: center;">
            <a href="productForm.php" style="text-decoration:none;">Add Product</a>
        </div>
        <div style="width: 60px;
    display: flex;
    background: #00ffc4;
    justify-content: center;
    align-items: center;
    padding: 5px;
     ">
            <a href="searchForm.php" style="text-decoration:none; color: #fff;">Search</a>
        </div>
    </div>
    <div class="container">  
        
        <div class="item">   
            <?php
                    if(isset($table_data) && count($table_data)>0){
                        foreach($table_data as $data){
                            $imageFileName = $data['image'];
                            $imagesFolderPath = 'images/';
                            $imageSrc = $imagesFolderPath . $imageFileName;
                            
                    echo "<div class='carts'>"
                
                    ?>

                    <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                        <label for="product name">Product name:</label>
                       <input style="padding:5px" value="<?= $data['product'] ?>" />
                    </div>
                    <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                        <label for="category">Category:</label>
                       <input style="padding:5px" value="<?= $data['category'] ?>" />
                    </div>
                    <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                        <label for="quantity">Quantity:</label>
                       <input style="padding:5px" value="<?= $data['quantity'] ?>" />
                    </div>
                    <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                        <label for="price">Price:</label>
                       <input style="padding:5px" value="<?= $data['price'] ?>" />
                    </div>
                    <div style="display:flex; margin-bottom:5px; justify-content:space-between;">
                        <label for="image">Image:</label>
                       
                        <img src="<?php echo $imageSrc; ?>" style="width:100px;"  alt="product <?php echo $data['id']; ?>" />
                    </div>
                    
                    <?php
                    echo "</div>";
                    }
                }
               
            ?>
            
        </div>
    </div>
    
</body>
</html>